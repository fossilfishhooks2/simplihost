A built in tutorial is a included feature. Before modifying or running any files, try starting simplihost.exe. Then, in your web
browser, head to 'localhost'. Make sure your volume is turned up!
Thank you for choosing Simplihost.
Apologies for the horrid text-to-speech......
We've included some test files in the examples folder.


4.0.0 new features
+ command execution on page send.
	Commands specified in file_map will be executed prior to file send. Note that the file is sent AFTER the command exits.
	This allows for modification of the files before send.
+ fixed HTTP header glitch with soft 404
+ transfer time command line option is now forced integer
+ ignores addittional command line options
+ a readme file
+ max file size is now 2,147,483,646 bytes (why you would ever need that fails us. This is a webserver, not a download platform)
+ max filename size 127 bytes
+ 404.bat execution
+ 404 request logging (latest only :( )
	Order is 1. log 404 link
		 2. run 404.bat (allows bat to identify what request and do something specific)
		 3. send potentially modified simplihost_defaults/404.html